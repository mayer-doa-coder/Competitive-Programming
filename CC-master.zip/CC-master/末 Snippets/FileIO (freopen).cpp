/* File io using freopen */

freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);

cin >> x;
cout << x;