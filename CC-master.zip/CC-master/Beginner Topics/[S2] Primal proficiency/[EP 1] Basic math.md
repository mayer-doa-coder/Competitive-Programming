# Basic math

<details open>
<summary>Problems</summary>
<ul>
    <li><a href="https://codeforces.com/problemset/problem/1341/A">CF 1341 A</a></li>
    <li><a href="https://codeforces.com/problemset/problem/1389/A">CF 1389 A</a></li>
    <li><a href="https://codeforces.com/problemset/problem/1194/A">CF 1194 A</a></li>
    <li><a href="https://codeforces.com/problemset/problem/1415/A">CF 1415 A</a></li>
    <li><a href="https://codeforces.com/problemset/problem/1327/A">CF 1327 A</a></li>
    <li><a href="https://codeforces.com/problemset/problem/1107/B">CF 1107 B</a></li>
    <li><a href="https://codeforces.com/problemset/problem/682/A">CF 682 A</a></li>
    <li><a href="https://codeforces.com/contest/633/problem/B">CF 633 B</a></li>
    <li><a href="https://codeforces.com/problemset/problem/707/C">CF 707 C</a></li>
    <li><a href="https://codeforces.com/contest/1538/problem/D">CF 1538 D</a></li>
</ul>
</details>