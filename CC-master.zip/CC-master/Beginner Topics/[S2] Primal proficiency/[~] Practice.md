# Practice
Mashups of topic relevant problems spanning a range of difficulties.

<details>
<summary>Mashup 1</summary>
<ul>
    <li><a href="https://codeforces.com/gym/103029/problem/B">CF 103029 B</a></li>
    <li><a href="https://codeforces.com/gym/102397/problem/J">CF 102397 J</a></li>
    <li><a href="https://codeforces.com/gym/102767/problem/A">CF 102767 A</a></li>
    <li><a href="https://codeforces.com/gym/102680/problem/D">CF 102680 D</a></li>
    <li><a href="https://codeforces.com/gym/102697/problem/159">CF 102697 159</a></li>
    <li><a href="https://codeforces.com/gym/102767/problem/B">CF 102767 B</a></li>
    <li><a href="https://codeforces.com/gym/102767/problem/D">CF 102767 D</a></li>
    <li><a href="https://codeforces.com/gym/102767/problem/C">CF 102767 C</a></li>
    <li><a href="https://codeforces.com/gym/102767/problem/E">CF 102767 E</a></li>
    <li><a href="https://codeforces.com/gym/102767/problem/F">CF 102767 F</a></li>
</ul>
</details>

<details>
<summary>Mashup 2</summary>
<ul>
    <li><a href="https://codeforces.com/contest/749/problem/A">CF 749 A</a></li>
    <li><a href="https://codeforces.com/contest/630/problem/J">CF 630 J</a></li>
    <li><a href="https://codeforces.com/contest/271/problem/B">CF 271 B</a></li>
    <li><a href="https://codeforces.com/contest/1303/problem/B">CF 1303 A</a></li>
    <li><a href="https://codeforces.com/contest/1332/problem/B">CF 1332 B</a></li>
    <li><a href="https://codeforces.com/contest/757/problem/B">CF 757 B</a></li>
    <li><a href="https://codeforces.com/contest/630/problem/K">CF 630 K</a></li>
    <li><a href="https://codeforces.com/contest/742/problem/B">CF 742 B</a></li>
    <li><a href="https://codeforces.com/contest/476/problem/D">CF 476 D</a></li>
    <li><a href="https://codeforces.com/contest/1247/problem/D">CF 1247 D</a></li>
</ul>
</details>

