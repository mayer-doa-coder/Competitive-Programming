# Practice
Mashups of topic relevant problems spanning a range of difficulties.

<details>
<summary>Mashup 1</summary>
<ul>
    <li><a href="https://codeforces.com/contest/1096/problem/A">CF 1096 A</a></li>
    <li><a href="https://codeforces.com/contest/1152/problem/A">CF 1152 A</a></li>
    <li><a href="https://codeforces.com/gym/103150/problem/E">CF 103150 E</a></li>
    <li><a href="https://codeforces.com/contest/1311/problem/A">CF 1311 A</a></li>
    <li><a href="https://codeforces.com/gym/102873/problem/A">CF 102873 A</a></li>
    <li><a href="https://codeforces.com/contest/1155/problem/B">CF 1155 B</a></li>
    <li><a href="https://codeforces.com/contest/1150/problem/B">CF 1150 B</a></li>
    <li><a href="https://codeforces.com/contest/342/problem/A">CF 342 A</a></li>
    <li><a href="https://codeforces.com/contest/1062/problem/A">CF 1062 A</a></li>
    <li><a href="https://codeforces.com/contest/1101/problem/C">CF 1101 C</a></li>
    <li><a href="https://codeforces.com/contest/148/problem/C">CF 148 C</a></li>
    <li><a href="https://codeforces.com/contest/106/problem/D">CF 106 D</a></li>
</ul>
</details>

<details>
<summary>Mashup 2</summary>
<ul>
    <li><a href="https://codeforces.com/contest/710/problem/A">CF 710 A</a></li>
    <li><a href="https://codeforces.com/contest/58/problem/A">CF 58 A</a></li>
    <li><a href="https://codeforces.com/contest/742/problem/A">CF 742 A</a></li>
    <li><a href="https://codeforces.com/contest/825/problem/A">CF 825 A</a></li>
    <li><a href="https://codeforces.com/contest/660/problem/A">CF 660 A</a></li>
    <li><a href="https://codeforces.com/contest/489/problem/A">CF 489 A</a></li>
    <li><a href="https://codeforces.com/contest/828/problem/A">CF 828 A</a></li>
    <li><a href="https://codeforces.com/contest/1271/problem/C">CF 1271 C</a></li>
    <li><a href="https://codeforces.com/contest/441/problem/B">CF 441 B</a></li>
    <li><a href="https://codeforces.com/contest/245/problem/E">CF 245 E</a></li>
    <li><a href="https://codeforces.com/contest/342/problem/B">CF 342 B</a></li>
    <li><a href="https://codeforces.com/contest/910/problem/C">CF 910 C</a></li>
</ul>
</details>