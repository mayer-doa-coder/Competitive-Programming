#### Hello World
```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
  int n;
  cin >> n;
  cout << 2 << " " << "Am I a Watermelon to you" << endl;
  return 0;
}
```
Try [this](https://codeforces.com/problemset/problem/4/A) problem.
